﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        picBuilding = New PictureBox()
        lblTitle = New Label()
        lblDo = New Label()
        txtInput = New TextBox()
        grpChoices = New GroupBox()
        radTwo = New RadioButton()
        radOne = New RadioButton()
        btnCalculate = New Button()
        lblResults = New Label()
        txtFile = New RichTextBox()
        btnSaveR = New Button()
        btnClearR = New Button()
        btnClearL = New Button()
        btnSaveF = New Button()
        lblFile = New Label()
        CType(picBuilding, ComponentModel.ISupportInitialize).BeginInit()
        grpChoices.SuspendLayout()
        SuspendLayout()
        ' 
        ' picBuilding
        ' 
        picBuilding.Image = CType(resources.GetObject("picBuilding.Image"), Image)
        picBuilding.Location = New Point(-1, 29)
        picBuilding.Name = "picBuilding"
        picBuilding.Size = New Size(263, 185)
        picBuilding.SizeMode = PictureBoxSizeMode.StretchImage
        picBuilding.TabIndex = 0
        picBuilding.TabStop = False
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Cooper Black", 24F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(280, 56)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(284, 36)
        lblTitle.TabIndex = 1
        lblTitle.Text = "Converter App 2"
        ' 
        ' lblDo
        ' 
        lblDo.AutoSize = True
        lblDo.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDo.Location = New Point(283, 133)
        lblDo.Name = "lblDo"
        lblDo.Size = New Size(254, 64)
        lblDo.TabIndex = 2
        lblDo.Text = "Enter a value and" & vbCrLf & "choose a conversion "
        ' 
        ' txtInput
        ' 
        txtInput.BackColor = Color.Indigo
        txtInput.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtInput.ForeColor = SystemColors.Window
        txtInput.Location = New Point(585, 164)
        txtInput.Name = "txtInput"
        txtInput.Size = New Size(100, 33)
        txtInput.TabIndex = 3
        txtInput.Text = "0"
        txtInput.TextAlign = HorizontalAlignment.Center
        ' 
        ' grpChoices
        ' 
        grpChoices.BackColor = Color.Indigo
        grpChoices.Controls.Add(radTwo)
        grpChoices.Controls.Add(radOne)
        grpChoices.Font = New Font("Segoe UI", 18.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        grpChoices.ForeColor = SystemColors.Window
        grpChoices.Location = New Point(337, 235)
        grpChoices.Name = "grpChoices"
        grpChoices.Size = New Size(313, 140)
        grpChoices.TabIndex = 4
        grpChoices.TabStop = False
        grpChoices.Text = "Convert Measurement"
        ' 
        ' radTwo
        ' 
        radTwo.AutoSize = True
        radTwo.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radTwo.Location = New Point(6, 85)
        radTwo.Name = "radTwo"
        radTwo.Size = New Size(186, 34)
        radTwo.TabIndex = 1
        radTwo.TabStop = True
        radTwo.Text = "Meters to Inches"
        radTwo.UseVisualStyleBackColor = True
        ' 
        ' radOne
        ' 
        radOne.AutoSize = True
        radOne.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        radOne.Location = New Point(6, 40)
        radOne.Name = "radOne"
        radOne.Size = New Size(192, 34)
        radOne.TabIndex = 0
        radOne.TabStop = True
        radOne.Text = "Inches to Meters "
        radOne.UseVisualStyleBackColor = True
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = SystemColors.ButtonHighlight
        btnCalculate.FlatAppearance.BorderColor = Color.White
        btnCalculate.FlatStyle = FlatStyle.Flat
        btnCalculate.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(358, 394)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(179, 34)
        btnCalculate.TabIndex = 5
        btnCalculate.Text = "Convert"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' lblResults
        ' 
        lblResults.AutoSize = True
        lblResults.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblResults.Location = New Point(376, 451)
        lblResults.Name = "lblResults"
        lblResults.Size = New Size(45, 25)
        lblResults.TabIndex = 8
        lblResults.Text = "000"
        ' 
        ' txtFile
        ' 
        txtFile.Location = New Point(-1, 235)
        txtFile.Name = "txtFile"
        txtFile.Size = New Size(263, 353)
        txtFile.TabIndex = 10
        txtFile.Text = ""
        ' 
        ' btnSaveR
        ' 
        btnSaveR.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSaveR.Location = New Point(358, 497)
        btnSaveR.Name = "btnSaveR"
        btnSaveR.Size = New Size(179, 34)
        btnSaveR.TabIndex = 11
        btnSaveR.Text = "Save Results"
        btnSaveR.UseVisualStyleBackColor = True
        ' 
        ' btnClearR
        ' 
        btnClearR.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClearR.Location = New Point(358, 554)
        btnClearR.Name = "btnClearR"
        btnClearR.Size = New Size(179, 34)
        btnClearR.TabIndex = 12
        btnClearR.Text = "Clear Results"
        btnClearR.UseVisualStyleBackColor = True
        ' 
        ' btnClearL
        ' 
        btnClearL.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClearL.Location = New Point(12, 612)
        btnClearL.Name = "btnClearL"
        btnClearL.Size = New Size(100, 31)
        btnClearL.TabIndex = 13
        btnClearL.Text = "Clear List"
        btnClearL.UseVisualStyleBackColor = True
        ' 
        ' btnSaveF
        ' 
        btnSaveF.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSaveF.Location = New Point(138, 612)
        btnSaveF.Name = "btnSaveF"
        btnSaveF.Size = New Size(112, 31)
        btnSaveF.TabIndex = 14
        btnSaveF.Text = "Save to File"
        btnSaveF.UseVisualStyleBackColor = True
        ' 
        ' lblFile
        ' 
        lblFile.AutoSize = True
        lblFile.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblFile.Location = New Point(376, 616)
        lblFile.Name = "lblFile"
        lblFile.Size = New Size(41, 21)
        lblFile.TabIndex = 15
        lblFile.Text = "ABC"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.LightSteelBlue
        ClientSize = New Size(800, 749)
        Controls.Add(lblFile)
        Controls.Add(btnSaveF)
        Controls.Add(btnClearL)
        Controls.Add(btnClearR)
        Controls.Add(btnSaveR)
        Controls.Add(txtFile)
        Controls.Add(lblResults)
        Controls.Add(btnCalculate)
        Controls.Add(grpChoices)
        Controls.Add(txtInput)
        Controls.Add(lblDo)
        Controls.Add(lblTitle)
        Controls.Add(picBuilding)
        Name = "Form1"
        Text = " "
        CType(picBuilding, ComponentModel.ISupportInitialize).EndInit()
        grpChoices.ResumeLayout(False)
        grpChoices.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents picBuilding As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblDo As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents grpChoices As GroupBox
    Friend WithEvents radTwo As RadioButton
    Friend WithEvents radOne As RadioButton
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblResults As Label
    Friend WithEvents txtFile As RichTextBox
    Friend WithEvents btnSaveR As Button
    Friend WithEvents btnClearR As Button
    Friend WithEvents btnClearL As Button
    Friend WithEvents btnSaveF As Button
    Friend WithEvents lblFile As Label

End Class
